import axios from 'axios';

class MurekaService {
  constructor() {
    this.apiKey = process.env.MUREKA_API_KEY;
    this.baseUrl = 'https://api.mureka.ai/v1';
    
    if (!this.apiKey) {
      throw new Error('MUREKA_API_KEY is required');
    }
  }

  /**
   * Check generation status
   * @param {string} taskId
   * @returns {Promise<object>}
   */
  async checkStatus(taskId) {
    try {
      const response = await axios.get(
        `${this.baseUrl}/status/${taskId}`,
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`
          }
        }
      );
      
      const data = response.data;
      
      // Normalize status response
      return {
        taskId: taskId,
        status: data.status || 'processing',
        progress: data.progress || 0,
        audioUrl: data.audio_url || data.result?.audio_url || null,
        duration: data.duration || data.result?.duration || null,
        error: data.error || null
      };
    } catch (error) {
      console.error('Mureka status check error:', error.response?.data || error.message);
      
      // If it's a 404, the task might not exist yet
      if (error.response?.status === 404) {
        return {
          taskId: taskId,
          status: 'pending',
          progress: 0,
          error: 'Task not found'
        };
      }
      
      throw new Error(
        error.response?.data?.error || 
        error.response?.data?.message || 
        'Failed to check audio status'
      );
    }
  }
}

export default MurekaService;